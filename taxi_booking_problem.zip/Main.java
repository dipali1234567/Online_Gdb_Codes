/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.*;

class Station{
    public String name;
    public ArrayList<Taxi>taxiesAtstation;
    
    station (String name)
    {
        this.name=name;
        this.taxiesAtstation=new ArrayList<Taxi>();
    }
    
    

    
}

class DemoOfTaxiAndStation{
    
  
  	ArrayList<Station>stations=new ArrayList<Station>();

	
		for(int i=0;i<6;i++)
		{
		    stations.add(new Station(String.valueOf('a'+i)));
		}
		
    public static  Station getStation(String name)
    {
        for(Station s: stations)
        if(s.name.equalsIgnorecase(name))
        return s;
    }
}

class Taxi{
   static int id=0;
   public  ArrayList<Integer>pickTime;
   public  ArrayList<Integer>dropTime;
   public ArrayList<Character>pickUppoint;
   public ArrayList<Character>dropPoint;
   public  char station;
   public int totalEarning;
   Taxi()
   {
       this.id=id;
       this.station='a';
       this.totalEarning=getEarning(this.pickUppoint,this.dropPoint);
       this.pickUppoint=new ArrayList<Character>();
       this.dropPoint=new ArrayList<Character>();
       this.pickTime=new ArrayList<Integer>();
       this.dropTgeeime=new ArrayList<Integer>();
       id=id+1;
   }
   
    static int getEarning(ArrayList<Character>pickUppoint,ArrayList<Character>dropPoint)
    {
        int earning=0;
        if(pickUppoint!=null&&dropPoint!=null)
        for(int i=0;i<pickUppoint.size();i++)
        {
            earning+=((dropPoint.get(i)-pickUppoint.get(i))*15-5)*10+100;
        }
        
        return earning;
    }
}
public class Main
{
	public static void main(String[] args) {
	    Scanner sc=new Scanner(System.in);
	System.out.println("Enter the taxies");
	int n=sc.nextInt();

		
	Taxi[]taxies=new Taxi[n];
	
	for(int i=0;i<n;i++)
	{
	    taxies[i]=new Taxi();
	    System.out.println(taxies[i].id+" ");
	}
	
	do{
	    
	    System.out.println("Options available");
	    System.out.println(" 1.Book taxi");
	    System.out.println("Exit");
	    System.out.println("Enter Your Choice");
	    int ch=sc.nextInt();
	    if(ch!=1)
	    {
	        System.out.println("Not valid Choice");
	        System.out.println("Please Enter once again");
	        ch=sc.nextInt();sc.nextLine();
	    }
	    
	    switch(ch)
	    {
	        case 1 : System.out.println("Enter pickup station");
	                 String s=sc.nextLine();
	                 System.out.println("Enter drop station");
	                 String s1=sc.nextLine();
	                 System.out.println("Enter pickup time");
	                 int t=sc.nextInt();
	                 
	                 
	    }
	    
	}while(ch!=2&&ch>0&&ch<2)
	
	}
}
