import java.util.*;
class Graph{
    
        ArrayList<GraphNode> nodelist1=new ArrayList<>();
        
        Graph(ArrayList<GraphNode>nodelist1)
    {
        this.nodelist1=nodelist1;}
        
        
         public void addEdgeUsingLL(int i,int j)
     {
        nodelist1.get(i).neighbours.add(nodelist1.get(j));
        System.out.println(nodelist1.get(i).name+" "+nodelist1.get(j).name);
        
     }
    
    public void displayforGraphUsingLL()
    {
        for(GraphNode g:nodelist1)
        {
            System.out.print(g.name+" :");
            int i=0;
            for( i=0;i<g.neighbours.size()-1;i++)
            {
                System.out.print(g.neighbours.get(i).name+"->");
                
            }
            System.out.print(g.neighbours.get(i).name);
            System.out.println();
        }
    }
    
    public void visit(GraphNode node)
    {
       Queue<GraphNode>queue=new LinkedList<>();
       if(node!=null)
       queue.add(node);
       while(!queue.isEmpty())
       {
           GraphNode p=queue.remove();
           if(!p.isvited)
           {
               System.out.print(p.name+" ");
               p.isvited=true;
           }
           
           for(GraphNode g:p.neighbours)
           {
               if(!g.isvited&&!queue.contains(g))
               queue.add(g);
           }
           
       }
    }
    
    public void BFS()
    {
        System.out.println("In BFS");
        for(GraphNode g: nodelist1)
        {
            if(!g.isvited)
            visit(g);
        }
    }
    
    
    public void visit1(GraphNode node)
    {
          Stack<GraphNode>stack=new Stack<>();
          if(node!=null)
          stack.push(node);
         
         while(!stack.isEmpty())
         {
             GraphNode p=stack.pop();
             System.out.print(p.name+" ");
             if(!p.isvited)
             p.isvited=true;
             
             for(GraphNode m:p.neighbours)
             {
                 if(!m.isvited)
                 {
                     stack.push(m);
                     m.isvited=true;
                 }
             }
         }
          
    }
    
    
    public void DFS()
    {
        System.out.println("\nIn DFS");
        for(GraphNode g: nodelist1)
        {
            if(!g.isvited)
            visit1(g);
        }
    }
    
    public void makeUnvisited()
    {
         for(GraphNode g: nodelist1)
        {
            if(g.isvited)
           g.isvited=false;
        }
    }
        
}


class GraphNode{
     public String name;
     public ArrayList<GraphNode>neighbours;
     public boolean isvited;
     
    public GraphNode(String name)
    {
        this.name=name;
        this.neighbours=new ArrayList<GraphNode>();
        this.isvited=false;
    }
}


public class Main
{
	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("We are implementing graph");
		
		ArrayList<GraphNode> g1=new ArrayList<GraphNode>();
		System.out.println("Enter the how many nodes in your graph are");
		
		int n=sc.nextInt();sc.nextLine();
		System.out.println("Enter  graph node value");
		for(int i=0;i<n;i++)
	{	
	    
	    String s=sc.nextLine();
	    g1.add(new GraphNode(s));
	
      	
	}
		
		
			Graph graphobj1=new Graph(g1);
			
			
			for(int i=0;i<n;i++)
			{
			    	for(int j=0;j<n;j++)
			    	{
			    	    System.out.println("Is there edge between "+g1.get(i).name+" and "+g1.get(j).name+" If yes Enter 1 else 0");
			    	    int yes=sc.nextInt();
			    	    if(yes==1)
			    	  
			    	    graphobj1.addEdgeUsingLL(i,j);
			    	    
			    	}
			}
		
		graphobj1.displayforGraphUsingLL();
		graphobj1.BFS();
		graphobj1.makeUnvisited();
		graphobj1.DFS();
		
	}
}



