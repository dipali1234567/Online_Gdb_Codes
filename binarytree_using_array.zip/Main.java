/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.*;

class BinaryTree
{
    String [] arr;
    int lastusedIndex;
    
    
    BinaryTree(int size)
    {
        arr=new String[size+1];
        lastusedIndex=0;
        System.out.println("Blank Tree of size "+size+" created");
    }
    
 public boolean isFull()
    {
        if(arr.length-1==lastusedIndex)
        return true;
        
        return false;
    }
    
    public void preOrderTraversal(int index)
    {
        if(index>lastusedIndex)
        return;
        
        System.out.print(arr[index]+" ");
        preOrderTraversal(index*2);
        preOrderTraversal(2*index+1);
    }
    
      public void inOrderTraversal(int index)
    {
        if(index>lastusedIndex)
        return;
        
        
        inOrderTraversal(index*2);
        System.out.print(arr[index]+" ");
        inOrderTraversal(2*index+1);
    }
    
       public void postOrderTraversal(int index)
    {
        if(index>lastusedIndex)
        return;
        
        
        postOrderTraversal(index*2);//----------->o(n/2)
        
        postOrderTraversal(2*index+1);//------------>o(n/2)
        System.out.print(arr[index]+" ");
    }
    
    public void levelOrderTraversal()
    {
       for(int i=1;i<arr.length;i++)
       {
           System.out.print(arr[i]+" ");
       }
    }
    
    public void delete(String s)
    {
        int index=search(s);
      
       
       if(index==-1)
       return;
       
       else
       {
           arr[index]=arr[lastusedIndex];
           lastusedIndex--;
           System.out.println("Node seccessfully deleted");
       }
       
       
    }
    
    public int search(String value)
    {
       for(int i=1;i<arr.length;i++)
       {
           if(arr[i].equalsIgnoreCase(value))
           {System.out.println("Value "+value+" found at index "+i);return i;}
           
       }
       
       System.out.println("Value "+value+" does not found ");
       return -1;
    }
    
    
    public void deleteBinaryTree()
    {
        try{
            arr=null;
            System.out.println("BinaryTree has been seccessfully deleted");
        }
        catch(Exception e)
        {
            System.out.println("There was an error while deleting the Binary Tree "+e);
        }
    }
    
 public void insert(String s)
    {
        if(!isFull()) //---------->o(1)
       { arr[lastusedIndex+1]=s;
        lastusedIndex++;
        System.out.println("Value is insertes seccessfully");}
        else
        System.out.println("BinaryTree is full");
    }
    
    
}
public class Main
{
	public static void main(String[] args) {
	
	BinaryTree bt=new BinaryTree(5);
	bt.insert("N1");
		bt.insert("N2");
			bt.insert("N3");
				bt.insert("N4");
					bt.insert("N5");
						bt.insert("N6");
	           bt.preOrderTraversal(1);
	           System.out.println();
	           bt.inOrderTraversal(1);
	           System.out.println();
	           bt.postOrderTraversal(1);
	            System.out.println();
	           bt.levelOrderTraversal();
	             System.out.println();
	           bt.search("N7");
	           bt.delete("n2");
	            bt.levelOrderTraversal();
	            System.out.println();
	            bt.deleteBinaryTree();
	            bt.deleteBinaryTree(); 
	
	}
}
