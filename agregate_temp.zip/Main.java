/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.*;

public class Main
{
	public static void main(String[] args) {
		
		int a[]=new int[]{6,-2,5};
		
		int b[]=new int[a.length];
			int c[]=new int[a.length];
			int n=a.length-1;
			b[0]=a[0];
			c[n]=a[n];
			for(int i=1;i<a.length;i++)
			{
			  int temp=b[i-1]+a[i];
			  if(temp>b[i-1])
			  {
			      b[i]=temp;
			  }
			  else if(a[i]>b[i-1])
			  {
			      b[i]=a[i];
			  }
			  else
			  b[i]=b[i-1];
			    
			    
			    temp=a[n-i]+b[n-i+1];
			    
			     if(temp>b[n-i+1])
			  {
			      b[n-i]=temp;
			  }
			  else if(a[n-i]>b[n-i+1])
			  {
			      b[n-i]=a[n-i];
			  }
			    else
			    b[n-i]=b[n-i+1];
			}
			System.out.println(Arrays.toString(a));
			System.out.println(Arrays.toString(b));
			
			System.out.println(Arrays.toString(c));
			
	}
}
