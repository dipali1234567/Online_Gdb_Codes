/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>
#include<bits/stdc++.h>
using namespace std;
string sorting(string &s)
{
    sort(s.begin(),s.end());
    return s;
}

void charsort(string s)
{
    int max[26]={0};
    for(int i=0;i<s.length();i++)
    {
        max[s[i]-'a']++;
    }
    for(int j=0;j<26;j++)
    for(int k=0;k<max[j];k++)
    cout<<char('a'+j);
}

int main()  
{
    //cout<<"Hello World";
    string s;
    cin>>s;
    cout<<sorting(s);
     charsort(s);
    return 0;
}
