/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/
import java.util.*;
public class Main
{
	public static void main (String[] args)
    {
        Integer[] a = {-1,-1,6,1,9,3,2,-1,4,-1};
        ArrayList<Integer>al=new ArrayList(Arrays.asList(a));
        for(int i=0;i<a.length;i++)
        {
            if(al.contains(i))
            a[i]=i;
            else
            a[i]=-1;
        }
 System.out.println(Arrays.toString(a));
 al.clear();
    }
}