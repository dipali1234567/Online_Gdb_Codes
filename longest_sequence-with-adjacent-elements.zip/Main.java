// Given an array A[] of size N, find the longest subsequence 
// such that difference between adjacent elements is one.



// Input: N = 7
// A[] = {10, 9, 4, 5, 4, 8, 6}
// Output: 3
// Explaination: The three possible subsequences 
// {10, 9, 8} , {4, 5, 4} and {4, 5, 6}.



class Solution{
    static int longestSubsequence(int n, int a[])
    {
        Map<Integer,Integer>map=new HashMap<Integer,Integer>();
       
        int mx=Integer.MIN_VALUE;
        for(int i=0;i<n;i++)
        {
            int l=0;
        
        if(map.containsKey(a[i]+1))
        l=map.get(a[i]+1);
        if(map.containsKey(a[i]-1)&&l<map.get(a[i]-1))
        l=map.get(a[i]-1);
        
        l=l+1;
        map.put(a[i],l);
            mx=Math.max(mx,map.get(a[i]));
              
           
        }
      return mx;
    }
}
