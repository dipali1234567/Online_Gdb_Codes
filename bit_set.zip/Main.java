


import java.util.*;
public class Main
{
	public static void main(String[] args) {
	
	      Scanner sc=new Scanner(System.in);
	      int n=sc.nextInt();
	      
	      String s=Integer.toBinaryString(n);
	      
	      int one=0;
	      int k=0;
	      int whichPower=k;
	     for(int i=s.length()-1;i>=0;i--){
	     if(s.charAt(i)=='1'){
	        one++; 
	        whichPower=k; }
	        k++;
	     
	}
	      if(one ==1)
	      System.out.println("Yes "+whichPower);
	      else
	       System.out.println("No");
	      
	}
}
