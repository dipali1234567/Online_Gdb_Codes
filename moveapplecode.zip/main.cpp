/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>
#include<bits/stdc++.h>

using namespace std;
int moveapple(int n,int a[])
{
    int sum=0,count=0;
    for(int i=0;i<n;i++)
    {
        sum+=a[i];
    }
    int t=sum/n;
    for(int i=0;i<n;i++)
    {
        if(a[i]<t)
        {sum=t-a[i];
        count+=sum;}
    }
    return count;
}

int main()
{
    int n;
    //cout<<"Hello World";
cout<<"Enter no of baskets";
cin>>n;
int a[n];
cout<<"Enter the elements in each basket";
for(int i=0;i<n;i++)
{
    cin>>a[i];
    
}
cout<<moveapple(n,a);
    return 0;
}
