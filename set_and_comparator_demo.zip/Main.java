/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/
import java.util.*;
class Student{
    public int roll_no;
    public String name;
    
    Student(int r,String n)
    {
        roll_no=r;
        name=n;
    }
}

class myComparator implements Comparator<Student>{
   
   
    public int compare(Student s1,Student s2)
    {
        return s2.name.compareTo(s1.name);
    }
    
    
}
public class Main
{
	public static void main(String[] args) {
		System.out.println("Hello World");
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter how many students data needs to added here");
		int n=sc.nextInt();sc.nextLine();
		
		Student []s=new Student[n];
		Set<Student> set=new TreeSet<>(new myComparator());
		System.out.println("Enter roll no and Name for each student");
		for(int i=0;i<n;i++)
		{
		       String m[]=sc.nextLine().split(" ");
		       int r=Integer.parseInt(m[0]);
		          
		       String name=m[1];
		       s[i]=new Student(r,name);
		       set.add(s[i]);
		       
		       
		}
		
		for(Student s: set)
		System.out.println(s.roll_no+" "+s.name);
		
	}
}
