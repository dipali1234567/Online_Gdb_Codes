
// Online C++ compiler to run C++ program online
#include <iostream>
using namespace std;

int main() {
    // Write C++ code here
    //
    std::cout << "Hello world!";
    int n,sum;
cout<<"Enter number of clients";
cin>>n;
if(n!=0){
int a[n];
for(int i=0;i<n;i++)
{
    cin>>a[i];
    sum=0;
    int temp=a[i];
    while(temp!=0)
    {
        sum +=temp%10;
        temp=temp/10;
    }
    cout<<sum<<" ";
}}
    return 0;
}