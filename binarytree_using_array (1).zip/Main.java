/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/
import java.util.*;
class BinaryTree{
    String a[];
    int lastUsedIndex;
    
    BinaryTree(int n)
    {
        a=new String[n+1]; // we are not using 0th index
        lastUsedIndex=0;
        System.out.println("Blank Tree of size "+n+" is created");
    }
    
    boolean isFull()
    {
         if((a.length-1)==lastUsedIndex)
       {System.out.println("Binary Tree is Full"); return true;}
        else 
        return false;
    }
    
    public void insertInBinaryTree(String s)
    {
       
        if(!isFull())
        {
            a[lastUsedIndex+1]=s;
            lastUsedIndex++;
            System.out.println("Value "+s+" has been added");
        }
        
    }
    
    
}
public class Main
{
	public static void main(String[] args) {
		System.out.println("Hello World");
		BinaryTree t=new BinaryTree(5);
		t.insertInBinaryTree("N1");
			t.insertInBinaryTree("N2");
				t.insertInBinaryTree("N3");	
				t.insertInBinaryTree("N4");	
				t.insertInBinaryTree("N5");
					t.insertInBinaryTree("N6");
		
		
	}
}

