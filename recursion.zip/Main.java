/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.*;
public class Main
{
    
    public static void string_combo(String s,ArrayList<String> a,int n,String temp,int index)
    {
       if(temp.length()==n)
        {a.add(s);
        return;}
        
        for(int i=index;i<n;i++)
        {
           // if(!temp.contains(s.charAt(i)))
            {
                temp+=s.charAt(i);
                string_combo(s,a,n,temp,i+1);
            }
        }
    }
    
    
    public static void combinations(int arr[],int temp[],int start,int end ,int index,int r)
    
    {
        //arr--given ArrayStoreException
        //temp=temporary array to store combinations
        //start=start of arr array
        //end=ending of arr array
        //index = index of temp array
        //r=size of  printting combinations
        if(index==r)
        {
            for(int i=0;i<index;i++)
            System.out.print(temp[i]+" ");
            System.out.println();
            return;
        }
        
        for(int i=start;i<=end&&end-i+1>=r-index;i++)
        {
           temp[index]=arr[i];
           combinations(arr,temp,i+1,end,index+1,r);
        }
        
    }
    
    public static void printCombinations(int a[],int n,int r)
    {
       int data[]=new int[r];
       combinations(a,data,0,n-1,0,r);
    }
	public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
// 	int n=sc.nextInt();
// int a[]=new int[n];
// for(int i=0;i<n;i++)
// a[i]=sc.nextInt();
// int r=sc.nextInt();
// printCombinations(a,n,r);

//string_combinations obj=new string_combinations();
 ArrayList<String> a=new ArrayList<>();
System.out.println("Enter the string to make it's combinations");
String s=sc.nextLine();
string_combo(s,a,s.length(),"",0);
System.out.println(a);

	}
}

