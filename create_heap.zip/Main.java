/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.*;
// class Node
// {
//     int data;
//     Node left;
//     Node right;
    
//     Node()
//     {
//         this.data=0;
//         this.left=null;
//         this.right=null;
//     }
//      Node(int data)
//     {
//         this.data=data;
//         this.left=null;
//         this.right=null;
//     }
    
//      Node(int data,Node left,Node right)
//     {
//         this.data=data;
//         this.left=left;
//         this.right=right;
//     }
    
// }


class Heap{
    
    
   int [] heap;
   int lastUsedIndex;
   
   Heap(int size)
   {
       heap=new int[size+1];
       lastUsedIndex=0;
   }
   
   
   public boolean isFull()
   {
       if(lastUsedIndex==heap.length)
       { return true;}
       
       return false;
   }
   
    public void insertInHeap(int data,String type)
    {
        if(!isFull())
        {
            
            heap[lastUsedIndex+1]=data;
            lastUsedIndex++;
            if(type=="Max")
           maxHeap(lastUsedIndex);
            else if(type=="Min")
          minHeap(lastUsedIndex);
            
            
        }
        
        else
        System.out.println("Can't insert Heap is full");
    }
    
    
    public void minHeap(int index)
    {
        if(index<=1)
        return;
        
        int parent=index/2;
        if(heap[parent]>heap[index])
        {
            int temp=heap[parent];
            heap[parent]=heap[index];
            heap[index]=temp;
            
        }
        
      minHeap(parent);
    }
    
    public void maxHeap(int index)
    {
        if(index<=1)
        return;
        
         int parent=index/2;
        if(heap[parent]<heap[index])
        {
            int temp=heap[parent];
            heap[parent]=heap[index];
            heap[index]=temp;
            
        }
        
        maxHeap(parent);
        
        
    }
    
    public void levelOrderT()
    {
        for(int i=1;i<heap.length;i++)
        System.out.print(" "+heap[i]);
    }
    
}

public class Main
{
	public static void main(String[] args) {
		
		Heap h=new Heap(10);
		h.insertInHeap(9,"Max");
			h.insertInHeap(8,"Max");
				h.insertInHeap(7,"Max");
					h.insertInHeap(6,"Max");
						h.insertInHeap(5,"Max");
							h.insertInHeap(4,"Max");
								h.insertInHeap(3,"Max");
									h.insertInHeap(2,"Max");
										h.insertInHeap(1,"Max");
										h.insertInHeap(10,"Max");
										
										System.out.println(h.heap.length);
										h.levelOrderT();
						Heap h1=new Heap(10);			
						System.out.println();
											h1.insertInHeap(9,"Min");
			h1.insertInHeap(8,"Min");
				h1.insertInHeap(7,"Min");
					h1.insertInHeap(6,"Min");
						h1.insertInHeap(5,"Min");
							h1.insertInHeap(4,"Min");
								h1.insertInHeap(3,"Min");
									h1.insertInHeap(2,"Min");
										h1.insertInHeap(1,"Min");
										h1.insertInHeap(10,"Min");
											h1.levelOrderT();	
					
		
		
	}
}
