/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/
import java.util.*;
public class Main
{
static int dir[][]={{1,0},{1,-1},{1,1},{-1,0},{-1,1},{-1,-1},{0,-1},{0,1}};


    public static boolean isvalid(int i,int j,int m,int n)
    {
        return i>=0&&i<m&&j>=0&&j<n;
    }
    public static int longestPath(int matrix[][],int i,int j,int vis[][],int m,int n)
    {
        if(vis[i][j]!=0)
        return vis[i][j];
        
        int max=0;
        for(int k=0;k<dir.length;k++)
        {
            int id=i+dir[k][0];
            int jd=j+dir[k][1];
            if(isvalid(id,jd,m,n)&&matrix[id][jd]==1)
            max=Math.max(max,longestPath(matrix,id,jd,vis,m,n));
        }
        
        vis[i][j]=1+max;
        return vis[i][j];
        
    }
    
	public static void main(String[] args) {
		System.out.println("Hello World");
		Scanner sc=new Scanner(System.in);
		int m=sc.nextInt();
		int n=sc.nextInt();
		int a[][]=new int[m][n];
		for(int i=0;i<m;i++)
		for(int j=0;j<n;j++)
		a[i][j]=sc.nextInt();
		
		int vis[][]=new int[m][n];
		int maxPath=0;
		for(int i=0;i<m;i++)
		{
		    for(int j=0;j<n;j++)
		    {
		        maxPath=Math.max(maxPath,longestPath(a,i,j,vis,m,n));
		    }
		}
		
		System.out.println(maxPath);
	}
}
