/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.*;
public class Main
{
    public static char[] swapp(String s,int i,int j)
    {
        char ch[]=s.toCharArray();
         while(j>=i)
	  {
	      if(s.charAt(i)==' '&&s.charAt(j)!=' ')
	      i++;
	       if(s.charAt(j)==' '&&s.charAt(i)!=' ')
	      j--;
        
        char temp=ch[i];
        ch[i]=ch[j];
        ch[j]=temp;
        
         i++;
	      j--;
	      
	  }
        
        return ch;
    }
	public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	
	   String s=sc.nextLine();
	   int i=0;
	   int j=s.length()-1;
	    char [] ch=new char[s.length()];
	 
	      
	      ch=swapp(s,i,j);
	     
	  for( i=0;i<ch.length;i++)
		System.out.print(ch[i]);
	}
}
