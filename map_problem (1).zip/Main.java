/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/
import java.util.*;
public class Main
{
  public static void main (String[]args)
  {

    Scanner sc = new Scanner (System.in);
      Map < String, String > map = new HashMap < String, String > ();
      map.put ("101", "186");
      map.put ("103", "107");
      map.put ("105", "190");
      map.put ("107", "99");
      map.put ("190", "45");
      map.put("133","124");
      map.put("154","133");
      map.put("144","43");
      map.put("178","105");
      map.put("169","42");
      map.put("163","190");
      map.put("198","1");
      map.put("186","107");

//              {
//     "101" : "186",
//     "103" : "107",
//     "105" : "190",
//     "107" : "99",
//     "190" : "45",
//     "133" : "124",
//     "154" : "133",
//     "144" : "43",
//     "178" : "105",
//     "169" : "42",
//     "163" : "190",
//     "198" : "1",
//     "186" : "107",
// 190 : [45]
// 163 : [190, 45]
// 186 : [107, 99]
// 154 : [133, 124]
// 198 : [1]
// 133 : [124]
// 144 : [43]
// 101 : [186, 107, 99]
// 178 : [105, 190, 45]
// 103 : [107, 99]
// 169 : [42]
// 105 : [190, 45]
// 107 : [99]


// }
//              System.out.println("Enter how many parent child pair you want to enter");
//              int n=sc.nextInt(); sc.nextLine();
//              for(int i=0;i<n;i++)
//              {
//                  System.out.println("Enter parent");
//                  String p=sc.nextLine();
//                  System.out.println("Enter child");
//                  String c=sc.nextLine();
//                  map.put(p,c);

//              }

      Map < String, ArrayList < String >> map1 =
      new HashMap < String, ArrayList < String >> ();
      int flag=0;

for (Map.Entry < String, String > e:map.entrySet ())
      {
        map1.put (e.getKey (), new ArrayList < String > ());
          String s=e.getValue();
          while(map.containsKey(s))
          {
              
              map1.get (e.getKey ()).add (s);
              s=map.get(s);
              
           }
           map1.get (e.getKey ()).add (s);
       
          
      }
      
      
      
       for (Map.Entry < String, ArrayList < String >> e:map1.entrySet ())
       {
           //if(e.getValue().size()!=1)
        	System.out.println (e.getKey () + " : " + e.getValue ());
           
           
       }
       
   	int pc=0;
   	int mc=0;
   	
   	  for (Map.Entry < String, ArrayList < String >> e:map1.entrySet ())
       {
          if(e.getValue ().size()==1)
          pc++;
          if(e.getValue ().size()>1)
          mc++;
           
       }
   	System.out.println("Number of parents with single child : "+pc);
   	System.out.println("Number of parents with Multiple childs : "+mc);
	

//     for (Map.Entry < String, String > e:map.entrySet ())
//       {
//          	String p = e.getKey ();
//      	for (Map.Entry < String, String > e1:map.entrySet ())
// 	   {
// 	    if (e1.getValue ().equals (p))
// 	      {
// 	          flag=1;
// 	    	map1.put (e1.getKey (), new ArrayList < String > ());
// 	    	map1.get (e1.getKey ()).add (p);
// 	    		map1.get (e1.getKey ()).add (e.getValue());
	    	
// 	      }
// 	  }
	  
// 	  if(flag==0)
// 	  {
// 	      	map1.put (e.getKey (), new ArrayList < String > ());
// 	      	map1.get (e.getKey ()).add (e.getValue());
// 	  }
// 	  else
// 	  flag=0;
	  
//       }


//     for (Map.Entry < String, ArrayList < String >> e:map1.entrySet ())
//       {
//     	System.out.println (e.getKey () + " : " + e.getValue ());
	
// 	//  for(String s :e.getValue())
// 	//  System.out.print(s+" ");
//       }

  }
}
