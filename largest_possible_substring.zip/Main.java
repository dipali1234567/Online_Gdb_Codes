/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.*;
public class Main
{
    static String reverse(String s)
    {
        String ans="";
        for(int i=s.length()-1;i>=0;i--)
        ans+=s.charAt(i);
        
        return ans;
    }
  public static void main (String[]args)
  {
  String s = new String ("viasdfevovees");
    String s1="";
    ArrayList<String>ans=new ArrayList<>();
    for(int i=s.length();i>=0;i--)
    {
        int j=0;
        for( j=0;j<i;j++)
        {
            s1=s.substring(j,i);
            // System.out.println(s1+" ");
            
            if(s1.length()!=1){
                
            //StringBuffer sbr=new StringBuffer(s1);
            String s2 =reverse(s1);
            //  System.out.println(s2);
           // System.out.println( s2.equals(s1));
            if(s2.equals(s1))
            ans.add(s1);
                
            }
        }
       
    }
  
  int max=ans.get(0).length();
  int index=0;
      for(int i=1;i<ans.size();i++)
      {
          if(ans.get(i).length()>max)
          {
              index=i;
              max=ans.get(i).length();
          }
      }
      
      System.out.println(ans.get(index));
      
  }
}
