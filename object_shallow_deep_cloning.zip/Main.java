/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/
import java.util.*;
class abc implements Cloneable{
    int i;
    int j;
    
    abc(){
        
    }
    abc(int i,int j)
    {
        this.i=i;
        this.j=j;
        
    }
    
    public String toString()
    {
        return this.i+" "+this.j;
    }
    
    
    public Object clone() throws CloneNotSupportedException //This method in object class is protected hence we cannot directly call this
    {
        return super.clone(); //calling clone method of object class
    }
    
    
}
public class Main
{
	public static void main(String[] args) throws CloneNotSupportedException{
		System.out.println("Hello World");
		
		abc obj=new abc(5,8);
		//shallow copy
		abc obj1=obj;
			System.out.println(obj.toString());
		System.out.println(obj1.toString());
		
		
		obj1.j=10;
		//change will reflect in obj because only one object and two references get created
		System.out.println(obj.toString());
		System.out.println(obj1.toString());
		
		//Deep copy
		
		abc obj2=new abc();
		obj2.i=obj.i;
		obj2.j=obj.j;
		
			System.out.println(obj.toString());
		System.out.println(obj2.toString());
		
		obj2.j=8;
		//change will not reflect in obj
			System.out.println(obj.toString());
		System.out.println(obj2.toString());
		
		
		//Deep copy is not suitable for very large elements in class hence Cloning
		
		abc obj3 = (abc)obj.clone();
		
		System.out.println(obj.toString());
		System.out.println(obj3.toString());
		
		obj3.j=9;
		System.out.println(obj.toString());
		System.out.println(obj3.toString());
		
		
	}
}
