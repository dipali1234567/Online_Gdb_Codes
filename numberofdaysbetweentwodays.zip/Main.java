/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.*;
class Date{
    
    public int day;
    public int month;
    public int year;
    
    Date(int day,int month,int year)
    {
        this.day=day;
        this.month=month;
        this.year=year;
    }
    
    public static int getNumberOfLeapYears(int m,int y)
    {
        if(m<=2)
        {
            y--;
        }
        
        return y/4-y/100+y/400;
        
    }
    
    public static long getNumberOfDays(Date []d)
    {
        //consider if currunt year needs to be consider as a leap or NoSuchMethodError
        long n1=d[0].year*365+getNumberOfLeapYears(d[0].month,d[0].year)+d[0].day;
        int [] months={31,28,31,30,31,30,31,31,30,31,30,31};
        for(int i=0;i<d[0].month-1;i++)
        n1+=months[i];
        
         long n2=d[1].year*365+getNumberOfLeapYears(d[1].month,d[1].year)+d[1].day;
       
        for(int i=0;i<d[0].month-1;i++)
        n2+=months[i];
        
        return n2-n1;
        
    }
    
}



public class Main
{
	public static void main(String[] args) {
          Scanner sc=new Scanner(System.in);
           	Date []d=new Date[2];
           		System.out.println("Enter first date as dd/mm/yyyy");
           		String [] date0=sc.nextLine().split("/");
           		
           		int day=Integer.parseInt(date0[0]);
           		int month=Integer.parseInt(date0[1]);
           		int year=Integer.parseInt(date0[2]);
           		
           		d[0]=new Date(day,month,year);
           		System.out.println("Enter the second date as dd/mm/yyyy");
           		String [] date1=sc.nextLine().split("/");
           	int day1=Integer.parseInt(date1[0]);
           		int month1=Integer.parseInt(date1[1]);
           		int year1=Integer.parseInt(date1[2]);
           		d[1]=new Date(day1,month1,year1);
           		
                
           		System.out.println(Date.getNumberOfDays(d));
	}
}

