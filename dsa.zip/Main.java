/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.*;
class BinaryNode
{
    public int data;
    public BinaryNode left;
    public BinaryNode right;
    public BinaryNode parent;
    
    BinaryNode(int data)
    {
        this.data=data;
        this.left=null;
        this.right=null;
        this.parent=null;
    }
}

class BinarySearchTree
{
    
    BinaryNode root;
    int f=0;
    BinarySearchTree ()
    {
        root=null;
    }
    
    public void insert(BinaryNode temp1,int value)
    {
       
        
        if(temp1==null)
        {
            BinaryNode newNode=new BinaryNode(value); 
           root=newNode;
         
            System.out.println("Root Node Created Successfully");
          
        }
        else
        {
            Queue<BinaryNode>queue=new LinkedList<>();
            queue.add(temp1);
            while(!queue.isEmpty())
            {
                BinaryNode temp=queue.remove();
                
                if(temp.left!=null&&temp.data<=value)
                queue.add(temp.left);
                else if(temp.right!=null&&data>value)
                queue.add(temp.right);
                else
                {
                    
                }
            }
        }

    }
    
    public void levelOrder()
    {
        if(root==null)
        {
            System.out.println("No element existn in BST");
            return;
        }
        else{
            Queue<BinaryNode>queue=new LinkedList<>();
            queue.add(root);
            while(!queue.isEmpty())
            {
                BinaryNode temp=queue.remove();
                System.out.print(temp.data+ " ");
                if(temp.left!=null)
                queue.add(temp.left);
                if(temp.right!=null)
                queue.add(temp.right);
            }
        }
    }
    
}
public class Main
{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter how many nodes do you want enter in BST");
		BinarySearchTree b=new BinarySearchTree();
		int n=sc.nextInt();
		for(int i=0;i<n;i++){
		b.insert(b.root,sc.nextInt());
		    System.out.println(b.root.data);
		    if(b.root.left!=null)
		    System.out.println(b.root.left.data);
		    if(b.root.right!=null)
		    System.out.println(b.root.right.data);
		}
		b.levelOrder();
	}
}
