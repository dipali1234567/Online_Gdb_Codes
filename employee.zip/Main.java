/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.*;
class Mycomparator implements Comparator<Employee>{
    public int compare(Employee e1,Employee e2)
    {
        return e1.name.compareTo(e2.name);
    }
}
class Mycomparator1 implements Comparator <Employee>{
    public int compare(Employee e1,Employee e2)
    {
        return e1.id-e2.id;
    }
}

class Employee
{
    String name;
    int id;
    
    Employee(String name,int id)
    {
        this.name=name;
        this.id=id;
    }
    
    public String toString()
    {
    return this.id+" "+this.name;
    }
}

class EmployeeDemo{
    ArrayList<Employee>employee;
    
    EmployeeDemo()
    {
        employee=new ArrayList<>();
    
    }
    public void addEmployee(String name,int id)
    {
        Employee e=new Employee(name,id);
        employee.add(e);
    }
    
    
    public void getEmployeeSortedByName()
    {
        Collections.sort(employee,new Mycomparator());
         System.out.println("\n\nEmployee Sorted by name");
        displayEmployee();
    }
    
    
    public void getEmployeeSortedByID()
    {
        Collections.sort(employee,new Mycomparator1());
        System.out.println("\n\nEmployee Sorted by ID");
        displayEmployee();
    }
    
    
    public void displayEmployee()
    {
        for(Employee e:employee)
        System.out.println(e.toString());
    }
    
}
public class Main
{
	public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
//	System.out.println("How many employee do you want to enter");
//	int n=sc.nextInt();
	EmployeeDemo e=new EmployeeDemo();
	e.addEmployee("Dipali",5);
	e.addEmployee("Arti",2);
	e.addEmployee("Kalyani",1);
	e.addEmployee("Siddhant",4);
	e.addEmployee("Sanket",3);
// 	for(int i=0;i<n;i++)
// 	{
// 	    System.out.println("Enter id");
// 	    int id=sc.nextInt();sc.nextLine();
// 	    System.out.println("Enter name");
// 	    String name=sc.nextLine();
	 //   e.addEmployee(name,id);
	    
// 	}
	
	e.displayEmployee();
	e.getEmployeeSortedByName();
	e.getEmployeeSortedByID();
	
	}
}
