/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.*;
public class Main
{
    static String getSortedString(String s)
    {
        String s1="";
        char ch[]=s.toCharArray();
        Arrays.sort(ch);
        for(char c:ch)
        s1+=c;
        
        return s1;
        
    }
	public static void main(String[] args) {
	//	System.out.println("Hello World");
		
		ArrayList<String>a=new ArrayList<String>();
// 		["eat","tea","tan","ate","nat","bat"]
		a.add("eat");
		a.add("tea");
		a.add("tan");
			a.add("ate");
				a.add("nat");
					a.add("bat");
		
		ArrayList<String>ans=new ArrayList<String>();
		
		
		int k=0;
		for(int i=0;i<a.size();i++)
		{
		    if(!a.get(i).equals(""))
		    {
		      
		        ans.add(a.get(i));
		       // a.set(i,"");
		        String temp=getSortedString(a.get(i));
		       //  System.out.println(temp);
		        for(int j=0;j<a.size();j++)
		        {
		            if(!a.get(j).equals("")&&j!=i)
		            {
		                String temp1=getSortedString(a.get(j));
		                if(temp1.equals(temp))
		               { ans.add(a.get(j));
		              // System.out.println(temp1);
		                a.set(j,"");}
		            }
		        }
		       
		       
		    }
		    if(ans.size()!=0)
		    System.out.println(ans);
		       ans.clear();
		}
	}
}
