/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.*;

public class Main
{
	public static void main(String[] args) {
		HashMap <String ,Integer>map=new HashMap<>();
		Scanner sc=new Scanner(System.in);
		
		String s[]=sc.nextLine().split(" ");
		
		
		for(int i=0;i<s.length;i++)
		{
		    if(!map.containsKey(s[i]))
		    map.put(s[i],1);
		    else
		    {int k=map.get(s[i])+1;  map.put(s[i],k);}
		}
		
		System.out.println(map);
		for(Map.Entry e : map.entrySet())
		System.out.println(e.getKey()+" "+e.getValue());
		
	}
}
