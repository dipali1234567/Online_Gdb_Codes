/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/
class Solution {
    public int longestOnes(int[] nums, int k) {
        
        int j=0;
        int m=k;
        int l=0;
        for(int i=0;i<nums.length;i++)
        {
            if(nums[i]==0)
                k--;
            while(k<0)
            {
                if(nums[j]==0)
                    k++;
                j++;
            }
            
         l=Math.max(l,i-j+1);
            
            
            
        }
        
        return l;
        
    }
}

public class Main
{
	public static void main(String[] args) {
		System.out.println("Hello World");
	}
}

// Input: nums = [1,1,1,0,0,0,1,1,1,1,0], k = 2
// Output: 6
// Explanation: [1,1,1,0,0,1,1,1,1,1,1]
// Bolded numbers were flipped from 0 to 1. The longest subarray is underlined.