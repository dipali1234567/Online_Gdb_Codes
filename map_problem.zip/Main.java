/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/
import java.util.*;
public class Main
{
  public static void main (String[]args)
  {

    Scanner sc = new Scanner (System.in);
      Map < String, String > map = new HashMap < String, String > ();
      map.put ("101", "186");
      map.put ("103", "107");
      map.put ("105", "190");
      map.put ("107", "99");
      map.put ("190", "45");

//              {
//     "101" : "186",
//     "103" : "107",
//     "105" : "190",
//     "107" : "99",
//     "190" : "45",
//     "133" : "124",
//     "154" : "133",
//     "144" : "43",
//     "178" : "105",
//     "169" : "42",
//     "163" : "190",
//     "198" : "1",
//     "186" : "107",
// }
//              System.out.println("Enter how many parent child pair you want to enter");
//              int n=sc.nextInt(); sc.nextLine();
//              for(int i=0;i<n;i++)
//              {
//                  System.out.println("Enter parent");
//                  String p=sc.nextLine();
//                  System.out.println("Enter child");
//                  String c=sc.nextLine();
//                  map.put(p,c);

//              }

      Map < String, ArrayList < String >> map1 =
      new HashMap < String, ArrayList < String >> ();

    for (Map.Entry < String, String > e:map.entrySet ())
      {
	String p = e.getKey ();
	for (Map.Entry < String, String > e1:map.entrySet ())
	  {
	    if (e1.getValue ().equals (p))
	      {
		map1.put (e1.getKey (), new ArrayList < String > ());
		map1.get (e1.getKey ()).add (p);
	      }
	  }
      }


    for (Map.Entry < String, ArrayList < String >> e:map1.entrySet ())
      {
	System.out.print (e.getKey () + " : " + e.getValue ());
	//  for(String s :e.getValue())
	//  System.out.print(s+" ");
      }

  }
}
