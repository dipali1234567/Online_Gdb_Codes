/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/

import java.util.*;
public class Main{
public static void dfs(int i,int j,int a[][],boolean visited[][],int n,int m)
{
    if(i<0&&i>=n&&j<0&&j>=m)
    return;
    
    if(i<0&&i>=n&&j<0&&j>=m&&visited[i][j])
    {
        return;
        
    }
    
    if((i<0&&i>=n&&j<0&&j>=m&&(!visited[i][j])))
    {
        visited[i][j]=true;
        dfs(i-1,j-1,a,visited,n,m);
        dfs(i-1,j,a,visited,n,m);
        dfs(i-1,j+1,a,visited,n,m);
        dfs(i,j-1,a,visited,n,m);
        dfs(i,j+1,a,visited,n,m);
       dfs(i+1,j-1,a,visited,n,m);
       dfs(i+1,j,a,visited,n,m);
       dfs(i+1,j+1,a,visited,n,m);
       
    }
    
}
public static void main(String []args)
{
     Scanner sc=new Scanner(System.in);
     int n=sc.nextInt();
     int m=sc.nextInt();
     int a[][]=new int[n][m];
     for(int i=0;i<n;i++)
     for(int j=0;j<m;j++)
     a[i][j]=sc.nextInt();
    int c=0;
     
     boolean visited[][]=new boolean[n][m];
     for(int i=0;i<n;i++)
     Arrays.fill(visited[i],false);
     for(int i=0;i<n;i++)
     {
         for(int j=0;j<m;j++)
         {
             if(a[i][j]==1&&!visited[i][j])
           {  c++;  dfs(i,j,a,visited,n,m);}
         }
     }
     System.out.println(c);
 
}
}