/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/
import java.util.*;
public class Main
{
	public static void main(String[] args) {
		System.out.println("Hello World");
		
		int n=15;
		char ch=(char)('A'+n-1);
		char a[][]=new char[n*2][n*2];
		for(int i=0;i<n;i++)
		{
		   //  int col=n*2-i-1;
		   for(int j=i;j<(n*2-i);j++)
		   {
		       a[i][j]=ch;
		       a[n*2-i-1][j]=ch;
		       a[j][n*2-i-1]=ch;
		       a[j][i]=ch;
		   }
		  
		 
		   
		   ch=(char)(ch-1);
	}
		
		for(int i=0;i<a.length;i++)
		{
		    System.out.println(Arrays.toString(a[i]));
		}
	}
}
