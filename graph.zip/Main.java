/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/
import java.util.*;
class Graph{
    
        ArrayList<GraphNode> nodelist=new ArrayList<>();
        int adjacencyMatrix[][];
        
    
 Graph(ArrayList<GraphNode>nodelist)
    {
        this.nodelist=nodelist;
       
        if(nodelist!=null)
        adjacencyMatrix=new int[nodelist.size()][nodelist.size()];
       // System.out.println("Size "+nodelist.size()+" ");
        
    }
    
    public ArrayList<GraphNode> getNeighbours(GraphNode node)
    {
        ArrayList<GraphNode>neighbours=new ArrayList<>();
        int index=nodelist.indexOf(node);
        for(int i=0;i<adjacencyMatrix.length;i++)
        {
            if(adjacencyMatrix[index][i]==1)
            {
                neighbours.add(nodelist.get(i));
            }
        }
        
        return neighbours;
    }
  
  public void BFS(GraphNode node)
  {
      Queue<GraphNode>queue=new LinkedList<GraphNode>();
      if(node!=null)
      queue.add(node);
      while(!queue.isEmpty())
      {
          GraphNode p=queue.remove();
        
          if(!p.isvisited)
          {  System.out.print(p.name+" ");
          p.isvisited=true;}
          
          ArrayList<GraphNode>neighbours=getNeighbours(p);
          for(GraphNode n:neighbours)
          {
              if(!n.isvisited)
              {
                  if(!queue.contains(n))
                  queue.add(n);
              }
          }
          
      }
      
  }
    
   
    
   
    
    public void addEdge(int i,int j)
    {
        adjacencyMatrix[i][j]=1;
        // adjacencyMatrix[nodelist.indexOf(b)][nodelist.indexOf(a)]=1;
    }
    
    public void display()
    {
        System.out.print(" : ");
        for(GraphNode s: nodelist)
        System.out.print(s.name+" ");
        System.out.println();
        
        for(int i=0;i<nodelist.size();i++)
        {
            System.out.print(nodelist.get(i).name+": ");
            for(int j=0;j<nodelist.size();j++)
            System.out.print(adjacencyMatrix[i][j]+" ");
            System.out.println();
        }
        
    }
}

class GraphNode{
    
    public String name;
    public boolean isvisited;
    public GraphNode(String name)
    {
        this.name=name;
        this.isvisited=false;
    }
    
    //
    
  
    
}





public class Main
{
	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("We are implementing graph");
		ArrayList<GraphNode> g=new ArrayList<GraphNode>();
		
		System.out.println("Enter the how many nodes in your graph are");
		
		int n=sc.nextInt();sc.nextLine();
		System.out.println("Enter  graph node value");
		for(int i=0;i<n;i++)
	{	
	    
	    String s=sc.nextLine();
	    g.add(new GraphNode(s));
	
       	
	}
		
		Graph graphobj=new Graph(g);
			
			
			
			for(int i=0;i<n;i++)
			{
			    	for(int j=0;j<n;j++)
			    	{
			    	    System.out.println("Is there edge between "+g.get(i).name+" and "+g.get(j).name+" If yes Enter 1 else 0");
			    	    int yes=sc.nextInt();
			    	    if(yes==1)
			    	   { graphobj.addEdge(i,j); 
			    	   }
			    	    
			    	}
			}
		graphobj.display();
	
		
		for(GraphNode m: g)
		{
		    if(!m.isvisited)
		    graphobj.BFS(m);
		}
	}
}




