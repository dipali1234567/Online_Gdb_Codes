/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.*;
public class Main
{
    static void getCombo(ArrayList<String>a,String s, String ans)
    {
        if(s.length()==0)
       { a.add(ans); return;}
        
        
        
        for(int i=0;i<s.length();i++)
        {
            char ch=s.charAt(i);
            
            String r=s.substring(0,i)+s.substring(i+1);
            getCombo(a,r,ans+ch);
        }
        
        
    }
    
    
	public static void main(String[] args) {
		System.out.println("Enter number to make combinations");
		Scanner sc=new Scanner(System.in);
// 		int n=sc.nextInt();
		String s=sc.nextLine();
		ArrayList<String> a=new ArrayList<>();
		getCombo(a,s,"");
		System.out.println(a);
	}
}
