/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.*;
public class Main
{
	public static void main(String[] args) {
		System.out.println("Hello World");
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int a[]=new int[n]
		for(int i=0;i<n;i++)
		a[i]=sc.nextInt();
		for(int i=0;i<n;i++)
		{
		    if(i%2==0)
		    {
		        
		        for(int j=i+1;j<n;j++)
		        {
		            if(a[j]>a[i])
		            {
		                int temp=a[i];
		                a[i]=a[j];
		                a[j]=temp;
		            }
		        }
		        
		        
		    }
		    else
		    {
		     
		      for(int j=i+1;j<n;j++)
		        {
		            if(a[j]<a[i])
		            {
		                int temp=a[i];
		                a[i]=a[j];
		                a[j]=temp;
		            }
		        }   
		    }
		}
		for(int i=0;i<n;i++)
		System.out.print(a[i]+" ");
	}
}
