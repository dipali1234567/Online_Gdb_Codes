/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.*;
public class Main
{
	public static void main(String[] args) {
		System.out.println("Hello World");
		Queue queue=new Queue();
		queue.enQueue(1);
		queue.enQueue(2);
		queue.enQueue(3);
		queue.enQueue(4);
		queue.enQueue(5);
		
		System.out.println(queue.deQueue()+" "+queue.deQueue()+" "+queue.deQueue());
		
		System.out.println(queue.isEmpty());
		System.out.println(queue.peek());
	}
}

class Queue{
    
   static Stack<Integer>stack1=new Stack<>();
   static   Stack<Integer>stack2=new Stack<>();
    
    public static void enQueue(int a)
    {
        stack1.push(a);
    }
    
    public static int deQueue()
    {
        if(!isEmpty()){
        if(stack2.isEmpty()){
        
           swapping();}
        
        
        return stack2.pop();}
        return -1;
    }
    
    private static boolean swapping()
    {
        if(stack1.isEmpty())
           { System.out.println("No element is present in queue"); return false;}
            else
          {  while(!stack1.isEmpty())
            stack2.push(stack1.pop());
              return true;
          }
    }
    
    public static boolean isEmpty()
    {
        if(stack1.isEmpty()&&stack2.isEmpty())
        return true;
        else return false;
        
    }
    
    
    public static int peek()
    {
        //int k=-1;
        if(!isEmpty()){
        if(stack2.isEmpty())
        swapping();
         return stack2.peek();
        }        
        //if(k!=-1)
       
        return -1;
        
    }
    
    
    
    
}
