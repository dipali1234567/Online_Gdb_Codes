/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/
// Input: nums = [100,4,200,1,3,2]
// Output: 4
// Explanation: The longest consecutive elements sequence is [1, 2, 3, 4]. Therefore its length is 4.

class Solution {
    public int longestConsecutive(int[] nums) {
        
        HashSet<Integer>set=new HashSet<>();
        
        for(int i=0;i<nums.length;i++)

        {
            set.add(nums[i]);
        }
        int l=0;
        for(int i=0;i<nums.length;i++)
        {
            if(!set.contains(nums[i]-1)){
               int k=nums[i];
                int t=0;
                while(set.contains(k))
                {
                    t++;
                    k++;
                }
                l=Math.max(t,l);
            }
        }
        return l;
    }
}

public class Main
{
	public static void main(String[] args) {
		System.out.println("Hello World");
	}
}
