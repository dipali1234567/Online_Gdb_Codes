/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<bits/stdc++.h>
#include<cstdlib>
using namespace std;
int main(){
    
    int n,t;
    cout<<"Enter size of array";
    cin>>n;
    int a[n];
    
    cout<<"Enter the elements in array";
    for(int i=0;i<n;i++)
    {
        cin>>a[i];
        
       /* cin>>t;
        if(i==0)
        {
           a[i]=t; 
        }
        else
        {
            if(t<a[i-1])
            {
                int temp=a[i-1];
                a[i-1]=t;
        
            }
        }
        */
    }
    sort(a,a+n);
    int sum=0;
    for(int i=1;i<n;i++)
    {
       sum+=abs(a[i]-a[i-1]); 
    }
    cout<<sum;
    
    return 0;
}
