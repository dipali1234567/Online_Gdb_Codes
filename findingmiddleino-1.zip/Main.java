/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
		System.out.println("Hello World");
		
		Stack s=new Stack();
		s.push(1);
			s.push(2);
				s.push(3);
					s.push(4);
						s.push(5);
							s.push(6);
							
							s.display();
							System.out.println(s.findMiddele());
							s.pop();
								System.out.println(s.findMiddele());
								s.push(6);
								s.push(7);
									System.out.println(s.findMiddele());
									s.display();
									s.deleteMid();
									s.display();
										System.out.println(s.findMiddele());
										s.pop();
											s.display();
											System.out.println(s.findMiddele());
	}
}


class DLLNode{
    int data;
    DLLNode next;
    DLLNode prev;
}


class Stack{
      
   static DLLNode head;
  static   DLLNode tail;
   static DLLNode mid;
    static int size;
    Stack()
    {
        head=null;
        tail=null;
        mid=null;
        size=0;
    }
    public void push(int data){
           
        if(size==0)
        {
                        DLLNode temp=new DLLNode();
            temp.data=data;
            temp.next=null;
            head=temp;
          
            mid=head;
            tail=head;
            size=1;
        }
        else{
            
            DLLNode temp=new DLLNode();
            temp.data=data;
            temp.next=null;
            temp.prev=tail;
            tail.next=temp;
            tail=temp;
            size++;
            
            if(size%2==0)
                if(mid!=null) { mid=mid.next;}
        }
        
    }
    
    public void display()
    {
        DLLNode temp=head;
        
        while(temp!=null)
        {
            System.out.print(temp.data+"->");
            temp=temp.next;
        }
        System.out.println("Null");
    }
    
    
    public int pop()
    {
         DLLNode r=null;
        if(size==1)
         {
              r=tail;
             head=null;
             tail=null;
            
         }
         else{
             r=tail;
             DLLNode temp=tail.prev;
             tail.prev=null;
          
             temp.next=null;
             tail=temp;
         }
         size--;
         //1 2 3 4 5 6
         if(size%2!=0)
         {
             mid=mid.prev;
         }
          return r.data;
    }
    
    
    public int findMiddele()
    {
        return mid.data;
    }
    
    public static void deleteMid()
    {
        if(size==1)
        {
            head=null;
            tail=null;
            mid=null;
            size--;
        }
       else   if(size==2)
       {
           head.next=null;
           mid.prev=null;
           mid=head;
           tail=head;
           size--;
       }
    else{    DLLNode p=mid.prev;
       DLLNode n=mid.next;
       p.next=n;
       n.prev=p;
       size--;
       if(size%2==0)
       {
           mid=n;
       }
       else
       mid=p;
       
    }
       
       
   }
}